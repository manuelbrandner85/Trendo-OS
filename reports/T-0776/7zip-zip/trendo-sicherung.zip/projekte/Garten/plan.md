# Beet
Tomaten, Bohnen, Kürbis
